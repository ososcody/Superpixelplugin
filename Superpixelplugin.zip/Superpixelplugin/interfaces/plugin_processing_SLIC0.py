# -*- coding: utf-8 -*-
"""
| ----------------------------------------------------------------------------------------------------------------------
| Date                : October 2021
| Copyright           : © 2021 by O. Weiland
| Email               : oweiland at uos.de
| Acknowledgements    : Based on 'Create A QGIS Plugin' [https://bitbucket.org/kul-reseco/create-qgis-plugin]
|                       Crabbé Ann and Somers Ben; funded by BELSPO STEREO III (Project LUMOS - SR/01/321)
|
| This file is part of the Superpixelplugin.
|
| This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
| License as published by the Free Software Foundation, either version 3 of the License, or any later version.
|
| This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
| warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
|
| You should have received a copy of the GNU General Public License (COPYING.txt). If not see www.gnu.org/licenses.
| ----------------------------------------------------------------------------------------------------------------------
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProcessingAlgorithm, QgsProcessingParameterRasterLayer, QgsProcessingParameterNumber, \
    QgsProcessingParameterFileDestination, QgsProcessingParameterBoolean, QgsProcessingContext

#from Superpixelplugin.core.my_code import MyCode
#from Superpixelplugin.interfaces import import_image, write_image


# Skript build arount the boiler plate code from:
# https://gis.stackexchange.com/questions/282773/writing-a-python-processing-script-with-qgis-3-0?rq=1
# See API: https://qgis.org/pyqgis/3.16/core/QgsProcessingAlgorithm.html
# And: https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/processing.html
import os

import numpy as np  # eventuell rasterio nehmen?

from osgeo import gdal
from osgeo.gdalconst import GDT_Float32
from qgis._core import QgsFillSymbol, QgsProcessingParameterVectorDestination
from qgis.core import QgsProcessingParameterFeatureSource
from qgis.core import QgsProcessingParameterRasterLayer
from qgis.core import QgsProcessingParameterRasterDestination

from skimage import exposure
from skimage.segmentation import slic  # import slic
# from skimage.segmentation import quickshift
# from skimage.segmentation import watershed
# from skimage.segmentation import felzenszwalb
# from skimage.color import label2rgb  # Import the label2rgb function from the color module

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                   QgsProcessingAlgorithm,
                   QgsProcessingParameterRasterLayer,
                   QgsProcessingParameterNumber,
                   QgsProcessingParameterRasterDestination)

class SuperpixelProcessingPluginSLIC0(QgsProcessingAlgorithm):  # TODO: RENAME
    INPUT_RASTER_A = 'INPUT_RASTER_A'
    # INPUT_RASTER_B = 'INPUT_RASTER_B'

    # INPUT_DOUBLE = 'INPUT_DOUBLE'
    NSEGMENTS = 'NSEGMENTS'
    COMPACTNESS = 'COMPACTNESS'
    SIGMA = 'SIGMA'
    STARTLABEL = 'STARTLABEL'

    OUTPUT_RASTER_A = 'OUTPUT_RASTER_A'

    # OUTPUT_RASTER_B = 'OUTPUT_RASTER_B'

    def __init__(self):  # TODO Hmmm...
        super().__init__()

    def name(self):
        return "SLIC0"  # TODO

    def tr(self, text):
        return QCoreApplication.translate("The SLIC0 Algorithm", text)

    def displayName(self):
        return self.tr("SLIC0")

    def icon(self):
        """ Should return a QIcon which is used for your provider inside the Processing toolbox. """
        return QIcon(':/plugin_logo')

    # DAS IST ZUVIEL, sonst entsteht noch eine extra Einteilung
    #def group(self):
    #    return self.tr("Superpixelplugin")  # Superpixelalgorithms")

    #def groupId(self):
    #    return "superpixelplugin"  # algorithms"

    def shortHelpString(self):
        return self.tr("The SLIC0 Superpixel Algorithm, originally "
                       "proposed by ACHANTA et al. 2010, see: Achanta, R. et al. (2010). SLIC Superpixels "
                       "(EPFL Technical Report, https://infoscience.epfl.ch/record/149300) in the implementation of "
                       "Scikit-image, see: van der Walt, S., Schönberger, J.L., Nunez-Iglesias, J., & Boulogne, F., et al. (2014). "
                       "Scikit-image: Image Processing in Python. PeerJ, 2, e453. DOI 10.7717/peerj.453")

    def helpUrl(self):
        return "https://github.com/ososcody/superpixelplugin#readme"

    def createInstance(self):
        return SuperpixelProcessingPluginSLIC0()

    def initAlgorithm(self, config=None, **kwargs):
        # See: https://docs.qgis.org/3.16/en/docs/user_manual/processing/scripts.html

        """
        # See: https://gis.stackexchange.com/questions/377793/how-to-group-parameters-in-pyqgis-processing-plugin
        param = QgsProcessingParameterString(
            self.NAME_OF_THE_PARAMETER,
            tr('Your label'),
            optional=False,
            defaultValue='If any default)

        # The line below will take default flags already there and adds the Advanced one
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)
        :param **kwargs:
        """

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_RASTER_A,
                # self.tr("Input Raster A")))  #, None, False))
                self.tr("Input Raster"), None, False))

        # self.addParameter(QgsProcessingParameterRasterLayer(
        #    self.INPUT_RASTER_B,
        #    self.tr("Input Raster B"), None, False))

        # self.addParameter(
        #    QgsProcessingParameterFeatureSource(
        #        self.INPUT_RASTER_A,
        #        self.tr('Input layer'),
        #        [QgsProcessing.TypeRaster]#VectorAnyGeometry]
        #    )
        # )

        # self.addParameter(QgsProcessingParameterNumber(
        #    self.INPUT_DOUBLE,
        #    self.tr("Input Double"),
        #    QgsProcessingParameterNumber.Double,
        #    QVariant(1.0)))
        """
        self.addParameter(QgsProcessingParameterNumber(
            self.NSEGMENTS,
            self.tr("Number of Segments"),
            QgsProcessingParameterNumber.Integer,
            QVariant(250)))
        """
        self.addParameter(QgsProcessingParameterNumber(
            self.COMPACTNESS,
            self.tr("Compactness"),

            defaultValue = 0.1, #  0.01, 0.1, 1, 10, 100
            minValue = 0,
            #maxValue = 1000000000,
            type = 1  #0 ist Integer, 1 ist Double
        ))

        self.addParameter(QgsProcessingParameterNumber(
            self.SIGMA,
            self.tr("Sigma"),
            defaultValue=1.0,
            minValue=0,
            # maxValue = 1000000000,
            type=1  # 0 ist Integer, 1 ist Double
        ))
        """
        self.addParameter(QgsProcessingParameterNumber(
            self.STARTLABEL,
            self.tr("Start Label"),
            # QgsProcessingParameterNumber.Integer,
            # QVariant(1.0)
            defaultValue=1.0,
            minValue=1,
            maxValue=1000000000,
            type=1 # 1 ist Double, 0 ist Integer
        ))
        """
        self.addParameter(QgsProcessingParameterRasterDestination(  # RASTER OUTPUT
            self.OUTPUT_RASTER_A,
            self.tr("SLIC0 Raster Segments"),
            None, False))


        # self.addParameter(QgsProcessingParameterRasterDestination(
        #    self.OUTPUT_RASTER_B,
        #    self.tr("Output Raster B"),
        #    None, False))

    def processAlgorithm(self, parameters, context, feedback, **kwargs):
        # raster_a = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_A, context)
        # raster_a = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_A, context)
        # raster_b = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_B, context)

        #  Experiment, ob AsSource oder AsRasterLayer...
        # TODO raster_a = self.parameterAsSource(parameters, self.INPUT_RASTER_A, context)
        self.raster_a = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_A, context)
        # !!!! JETZT HIER GANZ WICHTIG DIESER SCHRITT::
        # Code snippet verändert nach: https://gis.stackexchange.com/questions/357074/save-numpy-array-as-raster-in-a-processing-toolbox-qgis3
        # set provider to raster input as a dataProvider
        # provider = self.raster_a.dataProvider()
        # get the filepath of the input raster as a string
        # self.filepath_raster_a = str(provider.dataSourceUri())
        self.filepath_raster_a = str(self.raster_a.dataProvider().dataSourceUri())
        # ~~~~~

        # See filetypes: https://qgis.org/pyqgis/3.16/core/QgsProcessingAlgorithm.html
        # double_val = self.parameterAsDouble(parameters, self.INPUT_DOUBLE,context)
        #self.nSegments_slic = self.parameterAsInt(parameters, self.NSEGMENTS, context)
        self.compactness_slic = self.parameterAsInt(parameters, self.COMPACTNESS, context)
        self.sigma_slic = self.parameterAsDouble(parameters, self.SIGMA, context)
        """
        self.startLabel_slic = self.parameterAsInt(parameters, self.STARTLABEL, context)
        """
        output_path_raster_a = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER_A, context)
        # Der selbe Pfad in einer anderen Variablen
        self.outRaster = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER_A, context)
        # output_path_raster_b = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER_B, context)

        # output_path_vector_a = self.parameterAsOutputLayer(parameters, self.OUTPUT_VECTOR_A, context)
        #self.outVector = self.parameterAsOutputLayer(parameters, self.OUTPUT_VECTOR_A, context)
        # output_path_vector_stats = self.parameterAsOutputLayer(parameters, self.OUTPUT_VECTOR_STATS, context)
        #self.outVectorStats = self.parameterAsOutputLayer(parameters, self.OUTPUT_VECTOR_STATS, context)

        # DO SOME CALCULATION

        # Nachfolgender code ist angepasst aus dem tutorial von:
        # https://opensourceoptions.com/blog/python-geographic-object-based-image-analysis-geobia/
        driverTiff = gdal.GetDriverByName('GTiff')  # GDAL assign GTiff file driver (besser rasterio nehmen?)
        # global raster_dataset # set as a global variable

        raster_dataset = gdal.Open(
            # self.inRaster.dataProvider().dataSourceUri())  # use GDAL to open file from inRaster path
            # self.INPUT_RASTER_A.source())#.dataProvider().dataSourceUri())
            # TODO::::
            self.filepath_raster_a)

        # Get the input rasters nodata value
        self.noDataValue = raster_dataset.GetRasterBand(1).GetNoDataValue()  # get the NoDataValue

        self.nbands = raster_dataset.RasterCount  # get number of raster bands
        band_data = []  # create a list for the raster bands
        for i in range(1, self.nbands + 1):  # starting with band as 1
            band = raster_dataset.GetRasterBand(i).ReadAsArray()  # reads each band as ---> np array <---

            if self.noDataValue != None:
                # create the noData mask
                self.mask = band != self.noDataValue  # eigentlich inverted, aber unten durch multiplikation umgewandelt
            else:
                self.mask = False

            band_data.append(band)  # append the band as a np array to the band_data list
        band_data = np.dstack(band_data)  # put all in a single variable as a ---> stack of the bands <---

        # self.progressBar.setValue(10)

        # Check if multiband data:
        # TODO HIER WENN MEHR BÄNDER; DANN
        # (height, width, channels) = img.shape[:3]
        if band_data.shape[-1] > 1:  # if more than 1 channel is present in image, than compute gradient image, else pass
            self.channel_axis = -1
        else:
            self.channel_axis = None # In case of a grayscale image

        # normalize the raster band values
        # scale image values from 0.0 - 1.0
        self.img_normalized = exposure.rescale_intensity(band_data)

        # self.progressBar.setValue(20)

        # ---> jetzt kommt SLIC <---
        # self.img_normalized ist jetzt normalized (values from 0.0 - 1.0)

        # TODO: update variables???
        # self.setVariables()
        # ~~~~~ NEW ~~~~~~

        # self.progressBar.setValue(30)

        self.segments_slic = slic(image=self.img_normalized,
                                  slic_zero=True,  # SLIC ZERO

                                  mask=self.mask,

                                  #n_segments=self.nSegments_slic, # Berechnet selbst die beste Segmentanzahl
                                  compactness=self.compactness_slic,
                                  sigma=self.sigma_slic,
                                  start_label=1,  #self.startLabel_slic,
                                  channel_axis=self.channel_axis)  # =True  # TODO: eventuell noch checkbox einbauen?
        # )  # max_iter = 10 standard # argument multichannel = true standard!!!

        # self.progressBar.setValue(80)

        # ---> save segments to raster <----
        # segments_fn = self.outRaster  # to get the name from the input field or picker#

        segments_ds = driverTiff.Create(output_path_raster_a,
                                        # TODO  self.OUTPUT_RASTER_A,  # self.outRaster,  # segments_fn,
                                        raster_dataset.RasterXSize,
                                        raster_dataset.RasterYSize,
                                        1,
                                        gdal.GDT_UInt32)# VERÄNDERT!!! # gdal.GDT_Float32)
        segments_ds.SetGeoTransform(raster_dataset.GetGeoTransform())  # transform
        segments_ds.SetProjection(raster_dataset.GetProjectionRef())  # assign the CRS

        # Get the input rasters nodata value and set it to the new output as nodata value
        if self.noDataValue != None:
            segments_ds.GetRasterBand(1).SetNoDataValue(
                self.noDataValue)  # eigentlich so: raster_dataset.GetRasterBand(1).GetNoDataValue())
        else:
            pass

            # NICHT MEHR NÖTIG WEIL JETZT MASK PARAMETER: result = np.squeeze(self.segments_slic, axis=2) * self.mask
            # print(result.shape)
            """
            # RELABEL Segments
            # now the labels need to be recalculated
            # See: https://scikit-image.org/docs/dev/api/skimage.segmentation.html?highlight=watershed#skimage.segmentation.relabel_sequential
            from skimage.segmentation import relabel_sequential
            relab, fw, inv = relabel_sequential(result)

            segments_ds.GetRasterBand(1).WriteArray(relab) # hier wird segments raster geschrieben
            #print(np.unique(relab).size)  # Anzahl der Segmente

            segments_ds = None
            raster_dataset = None  # new

        else:
        """
        segments_ds.GetRasterBand(1).WriteArray(self.segments_slic) # hier wird segments raster geschrieben
        #print(np.unique(self.segments_slic).size)  # Anzahl der Segmente

        # segments_ds.GetRasterBand(1).WriteArray(self.segments_slic)  # hier wird segments geschrieben
        #print(output_path_raster_a)

        segments_ds = None
        raster_dataset = None  # new

        """
        results = {}
        results[self.OUTPUT_RASTER_A] = output_path_raster_a
        # results[self.OUTPUT_RASTER_B] = output_path_raster_b
        return results
        """
        return {self.OUTPUT_RASTER_A: output_path_raster_a}
