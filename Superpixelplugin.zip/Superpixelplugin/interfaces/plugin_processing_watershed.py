# -*- coding: utf-8 -*-
"""
| ----------------------------------------------------------------------------------------------------------------------
| Date                : October 2021
| Copyright           : © 2021 by O. Weiland
| Email               : oweiland at uos.de
| Acknowledgements    : Based on 'Create A QGIS Plugin' [https://bitbucket.org/kul-reseco/create-qgis-plugin]
|                       Crabbé Ann and Somers Ben; funded by BELSPO STEREO III (Project LUMOS - SR/01/321)
|
| This file is part of the Superpixelplugin.
|
| This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
| License as published by the Free Software Foundation, either version 3 of the License, or any later version.
|
| This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
| warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
|
| You should have received a copy of the GNU General Public License (COPYING.txt). If not see www.gnu.org/licenses.
| ----------------------------------------------------------------------------------------------------------------------
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProcessingAlgorithm, QgsProcessingParameterRasterLayer, QgsProcessingParameterNumber, \
    QgsProcessingParameterFileDestination, QgsProcessingParameterBoolean, QgsProcessingContext

#from Superpixelplugin.core.my_code import MyCode
#from Superpixelplugin.interfaces import import_image, write_image

# Skript build arount the boiler plate code from:
# https://gis.stackexchange.com/questions/282773/writing-a-python-processing-script-with-qgis-3-0?rq=1
# See API: https://qgis.org/pyqgis/3.16/core/QgsProcessingAlgorithm.html
# And: https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/processing.html

import numpy as np  # eventuell rasterio nehmen?

from osgeo import gdal
from osgeo.gdalconst import GDT_Float32
from qgis.core import QgsProcessingParameterFeatureSource
from qgis.core import QgsProcessingParameterRasterLayer
from qgis.core import QgsProcessingParameterRasterDestination

from skimage import exposure
from skimage.segmentation import watershed
from skimage.filters import sobel
from skimage.color import rgb2gray

# from skimage.segmentation import slic  # import slic
# from skimage.segmentation import quickshift
from skimage.segmentation import watershed
# from skimage.segmentation import felzenszwalb
# from skimage.color import label2rgb  # Import the label2rgb function from the color module

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterRasterDestination)


class SuperpixelProcessingPluginWatershed(QgsProcessingAlgorithm):  # TODO: RENAME
    INPUT_RASTER_A = 'INPUT_RASTER_A'
    # INPUT_RASTER_B = 'INPUT_RASTER_B'

    # INPUT_DOUBLE = 'INPUT_DOUBLE'
    MARKERS = 'MARKERS'
    COMPACTNESS = 'COMPACTNESS'

    OUTPUT_RASTER_A = 'OUTPUT_RASTER_A'

    # OUTPUT_RASTER_B = 'OUTPUT_RASTER_B'

    def __init__(self):
        super().__init__()

    def name(self):
        return "Watershed"

    def tr(self, text):
        return QCoreApplication.translate("The Watershed Algorithm", text)

    def displayName(self):
        return self.tr("Watershed")

    def icon(self):
        """ Should return a QIcon which is used for your provider inside the Processing toolbox. """
        return QIcon(':/plugin_logo')

    #def group(self):
    #    return self.tr("Superpixelalgorithms")

    #def groupId(self):
    #    return "superpixelalgorithms"

    def shortHelpString(self):
        return self.tr("The Watershed Superpixel Algorithm, originally "
                       "proposed by VINCENT et al. (1991), see: Vincent, L. & Soille, P. (1991). "
                       "Watersheds in digital spaces: an efficient algorithm based on immersion simulations. "
                       "IEEE Transactions on Pattern Analysis and Machine Intelligence, 13(6), 583–598. "
                       "DOI 10.1109/34.87344."
                       " in the implementation of "
                       "Scikit-image, see: van der Walt, S., Schönberger, J.L., Nunez-Iglesias, J., & Boulogne, F., et al. (2014). "
                       "Scikit-image: Image Processing in Python. PeerJ, 2, e453. DOI 10.7717/peerj.453")

    def helpUrl(self):
        return "https://github.com/ososcody/superpixelplugin#readme"

    def createInstance(self):
        return SuperpixelProcessingPluginWatershed()

    def initAlgorithm(self, config=None):
        # See: https://docs.qgis.org/3.16/en/docs/user_manual/processing/scripts.html

        """
        # See: https://gis.stackexchange.com/questions/377793/how-to-group-parameters-in-pyqgis-processing-plugin
        param = QgsProcessingParameterString(
            self.NAME_OF_THE_PARAMETER,
            tr('Your label'),
            optional=False,
            defaultValue='If any default)

        # The line below will take default flags already there and adds the Advanced one
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)
        """

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_RASTER_A,
                # self.tr("Input Raster A")))  #, None, False))
                self.tr("Input Raster"), None, False))

        # self.addParameter(QgsProcessingParameterRasterLayer(
        #    self.INPUT_RASTER_B,
        #    self.tr("Input Raster B"), None, False))

        # self.addParameter(
        #    QgsProcessingParameterFeatureSource(
        #        self.INPUT_RASTER_A,
        #        self.tr('Input layer'),
        #        [QgsProcessing.TypeRaster]#VectorAnyGeometry]
        #    )
        # )

        # self.addParameter(QgsProcessingParameterNumber(
        #    self.INPUT_DOUBLE,
        #    self.tr("Input Double"),
        #    QgsProcessingParameterNumber.Double,
        #    QVariant(1.0)))

        self.addParameter(QgsProcessingParameterNumber(
            self.MARKERS,
            self.tr("Markers"),
            QgsProcessingParameterNumber.Integer,
            QVariant(200)))

        self.addParameter(QgsProcessingParameterNumber(
            self.COMPACTNESS,
            self.tr("Compactness"),
            QgsProcessingParameterNumber.Double,
            QVariant(0.0010)))

        self.addParameter(QgsProcessingParameterRasterDestination(  # RASTER OUTPUT
            self.OUTPUT_RASTER_A,
            self.tr("Watershed Raster Segments"),
            None, False))

        # self.addParameter(QgsProcessingParameterRasterDestination(
        #    self.OUTPUT_RASTER_B,
        #    self.tr("Output Raster B"),
        #    None, False))

    def processAlgorithm(self, parameters, context, feedback):
        # raster_a = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_A, context)
        # raster_a = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_A, context)
        # raster_b = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_B, context)

        ### Experiment, ob AsSource oder AsRasterLayer...
        # TODO raster_a = self.parameterAsSource(parameters, self.INPUT_RASTER_A, context)
        self.raster_a = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER_A, context)
        # !!!! JETZT HIER GANZ WICHTIG DIESER SCHRITT::
        # Code snippet verändert nach: https://gis.stackexchange.com/questions/357074/save-numpy-array-as-raster-in-a-processing-toolbox-qgis3
        # set provider to raster input as a dataProvider
        provider = self.raster_a.dataProvider()
        # get the filepath of the input raster as a string
        self.filepath_raster_a = str(provider.dataSourceUri())
        #######

        # See filetypes: https://qgis.org/pyqgis/3.16/core/QgsProcessingAlgorithm.html
        # double_val = self.parameterAsDouble(parameters, self.INPUT_DOUBLE,context)
        self.markers_watershed = self.parameterAsInt(parameters, self.MARKERS, context)
        self.compactness_watershed = self.parameterAsInt(parameters, self.COMPACTNESS, context)

        output_path_raster_a = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER_A, context)
        # output_path_raster_b = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER_B, context)

        # DO SOME CALCULATION

        # Nachfolgender code ist angepasst aus dem tutorial von:
        # https://opensourceoptions.com/blog/python-geographic-object-based-image-analysis-geobia/
        driverTiff = gdal.GetDriverByName('GTiff')  # GDAL assign GTiff file driver (besser rasterio nehmen?)
        # global raster_dataset # set as a global variable

        raster_dataset = gdal.Open(
            # self.inRaster.dataProvider().dataSourceUri())  # use GDAL to open file from inRaster path
            # self.INPUT_RASTER_A.source())#.dataProvider().dataSourceUri())
            # TODO::::
            self.filepath_raster_a)

        # Get the input rasters nodata value
        self.noDataValue = raster_dataset.GetRasterBand(1).GetNoDataValue()  # get the NoDataValue

        import numpy.ma as ma

        self.nbands = raster_dataset.RasterCount  # get number of raster bands
        band_data = []  # create a list for the raster bands
        for i in range(1, self.nbands + 1):  # starting with band as 1
            band = raster_dataset.GetRasterBand(i).ReadAsArray()  # reads each band as ---> np array <---

            band_data.append(band)  # append the band as a np array to the band_data list
        band_data = np.dstack(band_data)  # put all in a single variable as a ---> stack of the bands <---

        # NEW
        """
        # create a masked array using the nodata value
        # import numpy.ma as ma
        noDataValue_mask = ma.masked_where(band == self.noDataValue, band)

        # normalize the raster band values
        # scale image values from 0.0 - 1.0
        self.img_normalized = exposure.rescale_intensity(band_data)
        """
        # self.progressBar.setValue(20)

        # NEW
        # create a masked array using the nodata value
        # import numpy.ma as ma
        noDataValue_mask = ma.masked_where(band == self.noDataValue, band)

        # normalize the raster band values
        # scale image values from 0.0 - 1.0
        img_normalized = exposure.rescale_intensity(band_data)
        print(img_normalized.shape)
        print(img_normalized.shape[-1])

        # CHECK for Shape and stack if necessary:
        if img_normalized.shape[-1] < 3:  # image_normalized[:,:,3]:   layer4[:,:,nchannel]=value

            # convert a grayscale image to a 3-channel image
            # https://stackoverflow.com/questions/40119743/convert-a-grayscale-image-to-a-3-channel-image/40119878
            # img_normalized = np.stack((img_normalized,)*3, axis=-1)
            # oder einfach: RGBstack = np.dstack((grey, grey, grey))
            # print(img_normalized.shape)

            # Einfach das Graustufenbild stacken
            img_normalized = np.dstack((img_normalized, img_normalized, img_normalized))

        else:
            pass
        # =====
        # COMPACT WATERSHED
        from skimage.segmentation import watershed
        from skimage.filters import sobel
        from skimage.color import rgb2gray
        # Watershed needs a gradient, computed on a gray input image:
        #cDas Gradientenbild berechnen
        gradient = sobel(rgb2gray(img_normalized))

        """
        # TODO HIER WENN MEHR BÄNDER; DANN
        # (height, width, channels) = img.shape[:3]

        if self.img_normalized.shape[
            -1] > 1:  # if more than 1 channel is present in image, than compute gradient image, else pass
            gradient = sobel(rgb2gray(self.img_normalized))
            # https://scikit-image.org/docs/dev/api/skimage.filters.html#skimage.filters.sobel
            # https://scikit-image.org/docs/dev/api/skimage.color.html?highlight=rgb2gray#skimage.color.rgb2gray
        else:
            # TODO so war es gerade noch: gradient = self.img_normalized  # if the image has only one band, set it as gradient # TODO: Ist das in Ordnung?
            gradient = sobel(
                self.img_normalized)  # if the image has only one band, set it as gradient # TODO: Ist das in Ordnung?

        # gradient = sobel(rgb2gray(self.img_normalized)) # TODO: Check, if this is OK or needs my if clause aove

        # NODATA MASK:
        #noDataValue_mask = ma.masked_where(band == self.noDataValue, band)

        if band_data.shape[-1] > 1:  # if more than 1 channel is present in image, set multichannel to True
            #result = np.squeeze(self.segments_felzenszwalb, axis=2) * self.mask
            pass

            # NOCH KEINE OPTION FÜR 2 kanalige DATEN...
        else:
            # np.expand_dims(noDataValue_mask, 1) #1) # expand the dimensions

            #noDataValue_mask = np.stack((noDataValue_mask)*self.nbands, axis=-1) # To add a channel axes of size nbands
             # oder wie oben und mit anzahl der channels multiplizieren.
            #noDataValue_mask = np.dstack((noDataValue_mask)) # To get 1 channel axes, wird dann aber -> 1, : , : channel first...

            #result = self.segments_felzenszwalb.squeeze() * self.mask
        """

        self.segments_watershed = watershed(gradient,
                                            markers=self.markers_watershed,
                                            compactness=self.compactness_watershed,
                                            mask=noDataValue_mask)
        # )  # max_iter = 10 standard # argument multichannel = true standard!!!

        # self.progressBar.setValue(80)

        # ---> save segments to raster <----
        # segments_fn = self.outRaster  # to get the name from the input field or picker#

        segments_ds = driverTiff.Create(output_path_raster_a,
                                        # TODO  self.OUTPUT_RASTER_A,  # self.outRaster,  # segments_fn,
                                        raster_dataset.RasterXSize,
                                        raster_dataset.RasterYSize,
                                        1,
                                        gdal.GDT_UInt32)
        # gdal.GetDataTypeName())  # GDT_Float32)
        segments_ds.SetGeoTransform(raster_dataset.GetGeoTransform())  # transform
        segments_ds.SetProjection(raster_dataset.GetProjectionRef())  # assign the CRS
        # segments_ds.GetRasterBand(1).WriteArray(self.segments_watershed)  # hier wird segments geschrieben
        # segments_ds = None

        # Get the input rasters nodata value and set it to the new output as nodata value
        segments_ds.GetRasterBand(1).SetNoDataValue(
            self.noDataValue)  # eigentlich so: raster_dataset.GetRasterBand(1).GetNoDataValue())

        # RELABEL Segments
        # after applying the nodata mask, the labels need to be recalculated
        # See: https://scikit-image.org/docs/dev/api/skimage.segmentation.html?highlight=watershed#skimage.segmentation.relabel_sequential
        from skimage.segmentation import relabel_sequential
        relab, fw, inv = relabel_sequential(self.segments_watershed)

        segments_ds.GetRasterBand(1).WriteArray(relab)  # hier wird segments geschrieben
        segments_ds = None
        raster_dataset = None  # new

        # IMPROVEMENT: ####
        # Taken from: https://gis.stackexchange.com/questions/213937/in-gdal-how-to-save-3-dimensional-array-as-stacked-raster-image
        # Array[np.isnan(Array)] = NDV
        # raster_dataset[np.isnan(raster_dataset)] = NDV  # find noData Values

        # for i, image in enumerate(raster_dataset, 1):
        #   raster_dataset.GetRasterBand(i).WriteArray(self.segments_watershed)
        # raster_dataset.GetRasterBand(i).SetNoDataValue(NDV)
        # raster_dataset.FlushCache() # RAM leeren durch speichern
        # return output_path_raster_a
        #########

        """
        results = {}
        results[self.OUTPUT_RASTER_A] = output_path_raster_a
        # results[self.OUTPUT_RASTER_B] = output_path_raster_b
        return results
        """
        return {self.OUTPUT_RASTER_A: output_path_raster_a}
