# -*- coding: utf-8 -*-
"""
| ----------------------------------------------------------------------------------------------------------------------
| Date                : October 2021
| Copyright           : © 2021 by O. Weiland
| Email               : oweiland at uos.de
| Acknowledgements    : Based on 'Create A QGIS Plugin' [https://bitbucket.org/kul-reseco/create-qgis-plugin]
|                       Crabbé Ann and Somers Ben; funded by BELSPO STEREO III (Project LUMOS - SR/01/321)
|
| This file is part of the Superpixelplugin.
|
| This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
| License as published by the Free Software Foundation, either version 3 of the License, or any later version.
|
| This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
| warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
|
| You should have received a copy of the GNU General Public License (COPYING.txt). If not see www.gnu.org/licenses.
| ----------------------------------------------------------------------------------------------------------------------
"""
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from Superpixelplugin.interfaces.plugin_processing import MyProcessingAlgorithm
from Superpixelplugin.interfaces.plugin_processing_SLIC import SuperpixelProcessingPluginSLIC

from Superpixelplugin.interfaces.plugin_processing_SLIC0 import SuperpixelProcessingPluginSLIC0
from Superpixelplugin.interfaces.plugin_processing_SLIC_plus import SuperpixelProcessingPluginSLICplus

from Superpixelplugin.interfaces.plugin_processing_felzenszwalb import SuperpixelProcessingPluginFelzenszwalb
from Superpixelplugin.interfaces.plugin_processing_watershed import SuperpixelProcessingPluginWatershed
from Superpixelplugin.interfaces.plugin_processing_quickshift import SuperpixelProcessingPluginQuickShift

class MyProcessingProvider(QgsProcessingProvider):

    def loadAlgorithms(self, *args, **kwargs):
        self.addAlgorithm(MyProcessingAlgorithm())
        self.addAlgorithm(SuperpixelProcessingPluginSLIC())         # Hiermit hinzufügen!!

        self.addAlgorithm(SuperpixelProcessingPluginSLIC0())
        self.addAlgorithm(SuperpixelProcessingPluginSLICplus())

        self.addAlgorithm(SuperpixelProcessingPluginFelzenszwalb())
        self.addAlgorithm(SuperpixelProcessingPluginWatershed())
        self.addAlgorithm(SuperpixelProcessingPluginQuickShift())

    def id(self, *args, **kwargs):
        """ The ID of your plugin, used for identifying the provider. This string should be a unique, short,
        character only string, eg "qgis" or "gdal". This string should not be localised. """
        return 'my_plugin_provider'

    def name(self, *args, **kwargs):
        """ The human friendly name of your plugin in Processing. This string should be as short as possible. """
        return self.tr('Superpixelplugin')

    def icon(self):
        """ Should return a QIcon which is used for your provider inside the Processing toolbox. """
        return QIcon(':/plugin_logo')